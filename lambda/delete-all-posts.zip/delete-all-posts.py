import json
import os
import boto3
import requests

def lambda_handler(event, context):
    secrets_client = boto3.client('secretsmanager')
    secret = secrets_client.get_secret_value(SecretId='GhostAdminAPIKey')
    api_key = json.loads(secret['SecretString'])['key']
    admin_url = json.loads(secret['SecretString'])['admin_url']

    headers = {
        'Authorization': f'Ghost {api_key}',
        'Content-Type': 'application/json'
    }

    # Get all posts
    posts = requests.get(f"{admin_url}/api/v3/admin/posts/?limit=all", headers=headers).json()['posts']
    for post in posts:
        id = post['id']
        requests.delete(f"{admin_url}/ghost/api/v3/admin/posts/{id}/", headers=headers)

    return {
        'statusCode': 200,
        'body': f"Deleted {len(posts)} posts"
    }
